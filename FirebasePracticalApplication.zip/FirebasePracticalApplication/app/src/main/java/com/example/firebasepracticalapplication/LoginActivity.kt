package com.example.firebasepracticalapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {
    private var mAuth: FirebaseAuth? = null
    var email=""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        mAuth = FirebaseAuth.getInstance()
        intiView()

    }

    private fun intiView() {
        btnLogin.setOnClickListener {
            email= intent.getStringExtra("USEREMAIL")!!
            if (edtLoginEmail.text.toString().isEmpty()) {
                edtLoginEmail.error = "Email Cant be Empty"
            } else if (edtLoginPassword.text.toString().isEmpty()) {
                edtLoginPassword.error = "Password Cant be Empty"
            } else {
                mAuth!!.signInWithEmailAndPassword(
                    edtLoginEmail.text.toString(),
                    edtLoginPassword.text.toString()
                )
                    .addOnCompleteListener(
                        this
                    ) { task ->
                        if (task.isSuccessful) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("TAG", "signInWithEmail:success")
                            val intent= Intent(this, MainActivity::class.java)
                            intent.putExtra("USEREMAIL", email)
                            startActivity(intent)
//                            val user = mAuth!!.currentUser
//                            updateUI(user)
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w("TAG", "signInWithEmail:failure", task.exception)
                            Toast.makeText(
                                this@LoginActivity, "Authentication failed.",
                                Toast.LENGTH_SHORT
                            ).show()
//                            updateUI(null)
                        }

                        // ...
                    }
            }
        }
    }
}