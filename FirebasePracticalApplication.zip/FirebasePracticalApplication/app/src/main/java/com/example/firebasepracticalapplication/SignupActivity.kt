package com.example.firebasepracticalapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_signup.*

class SignupActivity : AppCompatActivity() {
    private var mAuth: FirebaseAuth? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)
        intiView()

    }

    private fun intiView() {
        btnSignup.setOnClickListener {
            if (edtSignupEmail.text.toString().isEmpty()) {
                edtSignupEmail.error = "Email Cant be Empty"

            } else if (edtSignupPassword.text.toString().isEmpty()) {
                edtSignupPassword.error = "Password Cant be Empty"
            } else {
                mAuth = FirebaseAuth.getInstance()
                mAuth!!.createUserWithEmailAndPassword(
                    edtSignupEmail.text.toString(),
                    edtSignupPassword.text.toString()
                )
                    .addOnCompleteListener(
                        this
                    ) { task ->
                        if (task.isSuccessful) {

                            Log.d("TAG", "createUserWithEmail:success")

                            val intent = Intent(this, LoginActivity::class.java)
                            intent.putExtra("USEREMAIL", edtSignupEmail.text.toString().trim())
                            startActivity(intent)
//                    val user = mAuth!!.currentUser
//                    updateUI(user)
                        } else {

                            Log.w("TAG", "createUserWithEmail:failure", task.exception)
                            Toast.makeText(
                                this@SignupActivity, "Authentication failed.",
                                Toast.LENGTH_SHORT
                            ).show()
//                    updateUI(null)
                        }

                        // ...
                    }
            }
        }
    }
}